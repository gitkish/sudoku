package com.soduku;

import java.util.Arrays;

/**This is to hold all properties of Sudoku and its validation functionality.
 * @author kish-pc
 *
 */
public class Sudoku {
	
	int[][] matrix;
	int rows;
	int cols;
	int exteriorSize;
	int interiorSize;
	boolean flag;
	
	public Sudoku(int[][] args) {
		this.matrix = args;
	}

	public int[][] getMatrix() {
		return matrix;
	}

	public void setMatrix(int[][] matrix) {
		this.matrix = matrix;
	}

	public int getRows() {
		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
	}

	public int getCols() {
		return cols;
	}

	public void setCols(int cols) {
		this.cols = cols;
	}

	public int getExteriorSize() {
		return exteriorSize;
	}

	public void setExteriorSize(int exteriorSize) {
		this.exteriorSize = exteriorSize;
	}

	public int getInteriorSize() {
		return interiorSize;
	}

	public void setInteriorSize(int interiorSize) {
		this.interiorSize = interiorSize;
	}

	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	
	/**
	 * This will validate and return true or false. 
	 * @author kish
	 *
	 */
	public boolean isValid() {
		if(matrix != null) {
			printMatrix();
			rows = matrix.length;
			cols = matrix[0].length;
			exteriorSize = rows;
			interiorSize = (int)Math.sqrt(rows);
			
			if(interiorSize * interiorSize != rows) {
				log("Invalid Sudoku");
				System.exit(1);
			}
			
			for(int r=0;r<exteriorSize;r++ ) {
				if(!validate(matrix[r])) {
					log("The row number "+(r+1)+" is invalid = ");
					print(matrix[r],1);
					return false;
				}
			}
		
			for(int row=0;row<exteriorSize;row++) {
				int[] col = new int[exteriorSize];
				
				for(int c=0;c<col.length;c++) {
					col[c] = matrix[c][row];
				}
				if(!validate(col)) {
					log("The column number "+(row+1)+" is invalid = ");
					print(col,2);
					return false;
				}
			}
			
			
	        for (int i = 0; i < interiorSize; i++) {
	            int k = 0;
	            int[] list = new int[matrix.length];

	            for (int row = i * interiorSize; row < (i * interiorSize + interiorSize); row++) {

	                for (int column = i * interiorSize; column < (i * interiorSize + interiorSize); column++) {
	                    list[k++] = matrix[row][column];
	                }

	            }
	            if (!validate(list))
	                return false;
	        }			
		}
		
		return true;
	}
	
	/**
	 * This will validate each row & column 
	 * @author kish
	 *
	 */
    private boolean validate(int[] rowOrCol) {

        int length = rowOrCol.length;
        int[] temp = Arrays.copyOf(rowOrCol, rowOrCol.length);
        Arrays.sort(temp);

        for (int i = 0; i < length; i++) {
            if (temp[i] != i + 1) {
                return false;
            }
        }
        return true;
    }	

	private void log(String log) {
		System.out.println(log);
	}
    
	/**
	 * This is to print the given Sudoku. 
	 * @author kish
	 *
	 */
	private void printMatrix() {
		if(matrix != null) {
			log("The given Soduku is ");
			log("----------");
			for(int i=0;i<matrix.length;i++) {
				print(matrix[i],1);
				log("\n");
			}
			log("----------");
		}
	}
	
	private void print(int[] line,int rowCol) {
		if(rowCol == 1) { // row
			for(int j=0;j<line.length;j++) {
				System.out.print(line[j]+" ");
			}
		} else { // Column
			for(int j=0;j<line.length;j++) {
				System.out.println(line[j]);
			}
		}
	}
    
}
