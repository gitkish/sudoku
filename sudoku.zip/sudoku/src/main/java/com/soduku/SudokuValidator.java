package com.soduku;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;



/**
 * This is to Validate given Sudoku solution and print either valid or invalid. 
 * Input param is the file containing the solution matrix
 * * @author kish
 *
 */
public class SudokuValidator {

	public static void main(String[] path) {
		SudokuValidator validator = new SudokuValidator();
		validator.verify(path);
	}
	
	public void verify(String[] path) {
		
		if(path == null || path.length == 0) {
			Scanner scan = new Scanner(System.in);
			log("Please enter the full path of the input file");
			path = new String[1];
			path[0] = scan.next();
			scan.close();
		}
		
		int[][] matrix = parse(path);

		Sudoku sudoku = new Sudoku(matrix);
		if(sudoku.isValid())
			log("\n\nGiven Soduku is valid");
		else 
			log("\n\nGiven Soduku is invalid");
	}

	
	/**
	 * Parse the input file and populate matrix array for further processing
	 * @author kish
	 *
	 */	
	private int[][] parse(String[] path) {
		int[][] matrix = null;

		if (path == null || path[0].equals("")) {
			log("Invalid input");
			System.exit(1);
		}

		File file = new File(path[0]);
		DataInputStream dis = null;
		
		if (!file.exists()) {
			log("Input file does not exists");
			System.exit(1);
		}

		try {
			FileInputStream fis = new FileInputStream(path[0]);
			dis = new DataInputStream(fis);

			BufferedReader reader = new BufferedReader(new InputStreamReader(dis));

			String strRow;
			ArrayList<String> list = new ArrayList<String>();

			while ((strRow = reader.readLine()) != null) {
				list.add(strRow);
			}

			int rowSize = list.size();
			int colSize = 0;

			for (int i = 0; i < list.size(); i++) {
				String row = list.get(i);
				String[] rows = row.split(",");
				colSize = rows.length;

				if (rowSize != colSize) {
					log("Number of rows and columns are not same and hence its an invalid.");
					System.exit(1);
				}

				if (i == 0)
					matrix = new int[colSize][rowSize]; // Initialise only once

				for (int j = 0; j < rows.length; j++) {
					matrix[i][j] = Integer.parseInt(rows[j]);
				}
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			// Close the input stream
			try {
				dis.close();;
			} catch (IOException ioe) {
				log("ioException during close!");
			}
		}

		return matrix;
	}

	static void log(String log) {
		System.out.println(log);
	}

}
