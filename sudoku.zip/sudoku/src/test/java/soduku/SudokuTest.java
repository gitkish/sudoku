package soduku;

import org.junit.Test;

import com.soduku.SudokuValidator;

public class SudokuTest{
	
	@Test
	public void testSudoku() {
		SudokuValidator validator = new SudokuValidator();
		String[] path = {"D:\\Workspace\\JavaEE\\sudoku\\src\\main\\resources\\Sudoku_9X9.txt"};
		validator.verify(path);		
	}

}
